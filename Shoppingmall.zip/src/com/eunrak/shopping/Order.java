package com.eunrak.shopping;

public class Order {
	public Product selectedProduct;

	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
}
